# ST7735 driver for MicroPython (RGB565, landscape 160x128, no auto-show)
from machine import Pin, SPI
import time, gc, framebuf

BLACK   = 0x0000
BLUE    = 0x001F
RED     = 0xF800
GREEN   = 0x07E0
CYAN    = 0x07FF
MAGENTA = 0xF81F
YELLOW  = 0xFFE0
WHITE   = 0xFFFF
GRAY    = 0x8410

class ST7735(framebuf.FrameBuffer):
    def __init__(self, spi, cs, dc, rst, width=160, height=128):
        self.spi = spi
        self.cs = cs
        self.dc = dc
        self.rst = rst
        self.width = width
        self.height = height

        gc.collect()
        self.buffer = bytearray(self.width * self.height * 2)
        print('RGB565 buffer allocated {}x{}'.format(self.width, self.height))

        super().__init__(self.buffer, self.width, self.height, framebuf.RGB565)
        self._init_pins()
        self.reset()
        self._init_display()

    def _init_pins(self):
        self.cs.init(Pin.OUT, value=1)
        self.dc.init(Pin.OUT, value=0)
        self.rst.init(Pin.OUT, value=1)

    def _write_cmd(self, cmd):
        self.dc.value(0)
        self.cs.value(0)
        self.spi.write(bytearray([cmd]))
        self.cs.value(1)

    def _write_data(self, data):
        self.dc.value(1)
        self.cs.value(0)
        if isinstance(data, int):
            self.spi.write(bytearray([data]))
        else:
            self.spi.write(data)
        self.cs.value(1)

    def reset(self):
        self.rst.value(1)
        time.sleep_ms(50)
        self.rst.value(0)
        time.sleep_ms(50)
        self.rst.value(1)
        time.sleep_ms(50)

    def _init_display(self):
        self._write_cmd(0x01); time.sleep_ms(150)
        self._write_cmd(0x11); time.sleep_ms(500)
        self._write_cmd(0xB1); self._write_data(b'\x01\x2C\x2D')
        self._write_cmd(0xB2); self._write_data(b'\x01\x2C\x2D')
        self._write_cmd(0xB3); self._write_data(b'\x01\x2C\x2D\x01\x2C\x2D')
        self._write_cmd(0xB4); self._write_data(b'\x07')
        self._write_cmd(0xC0); self._write_data(b'\xA2\x02\x84')
        self._write_cmd(0xC1); self._write_data(b'\xC5')
        self._write_cmd(0xC2); self._write_data(b'\x0A\x00')
        self._write_cmd(0xC3); self._write_data(b'\x8A\x2A')
        self._write_cmd(0xC4); self._write_data(b'\x8A\x8A')
        self._write_cmd(0xC5); self._write_data(b'\x0E')
        self._write_cmd(0x20)
        self._write_cmd(0x36); self._write_data(b'\x68')   # 横屏
        self._write_cmd(0x3A); self._write_data(b'\x05')
        self._write_cmd(0x2A); self._write_data(bytearray([0x00,0x00,0x00,self.width-1]))
        self._write_cmd(0x2B); self._write_data(bytearray([0x00,0x00,0x00,self.height-1]))
        self._write_cmd(0xE0); self._write_data(b'\x02\x1c\x07\x12\x37\x32\x29\x2d\x29\x25\x2B\x39\x00\x01\x03\x10')
        self._write_cmd(0xE1); self._write_data(b'\x03\x1d\x07\x06\x2E\x2C\x29\x2D\x2E\x2E\x37\x3F\x00\x00\x02\x10')
        self._write_cmd(0x13); time.sleep_ms(10)
        self._write_cmd(0x29); time.sleep_ms(100)

    def _set_window(self, x0, y0, x1, y1):
        self._write_cmd(0x2A); self._write_data(bytearray([0x00,x0,0x00,x1]))
        self._write_cmd(0x2B); self._write_data(bytearray([0x00,y0,0x00,y1]))
        self._write_cmd(0x2C)

    def show_partial(self, y0, y1):
        if y0 < 0: y0 = 0
        if y1 >= self.height: y1 = self.height - 1
        self._set_window(0, y0, self.width-1, y1)
        start = y0 * self.width * 2
        end = (y1 + 1) * self.width * 2
        chunk_size = 512
        for i in range(start, end, chunk_size):
            chunk_end = min(i + chunk_size, end)
            self._write_data(self.buffer[i:chunk_end])

    def show(self):
        self.show_partial(0, self.height - 1)

    # 注意：fill 和 text 不再自动 show
    def fill(self, color):
        super().fill(color)

    def text(self, string, x, y, color=WHITE, size=1):
        super().text(string, x, y, color)
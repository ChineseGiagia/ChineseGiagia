from machine import Pin, SoftSPI, PWM, ADC, RTC
import time, gc, ujson, math, os
import network, ntptime
import st7735

# ---------- WiFi 配置 ----------
WIFI_SSID = "502"
WIFI_PASSWORD = "a123456a"

# ---------- 天气配置 ----------
WEATHER_LAT = "24.31"
WEATHER_LON = "109.42"

# 屏幕初始化
spi = SoftSPI(baudrate=8000000, polarity=0, phase=0,
              sck=Pin(18), mosi=Pin(2), miso=Pin(12))
display = st7735.ST7735(spi, cs=Pin(5), dc=Pin(16), rst=Pin(17))

backlight = PWM(Pin(4), freq=1000, duty=1023)
buzzer = PWM(Pin(13), freq=1000, duty=0)

joy_x = ADC(Pin(1))
joy_y = ADC(Pin(6))
joy_sw = Pin(14, Pin.IN, Pin.PULL_UP)
joy_x.atten(ADC.ATTN_11DB)
joy_y.atten(ADC.ATTN_11DB)

battery_adc = ADC(Pin(7))
battery_adc.atten(ADC.ATTN_11DB)

# 数据持久化
DATA_FILE = "device_data.json"
rtc = RTC()
alarms = []
countdown_target = (2029, 6, 7, 9, 0, 0)
weather_data = []
weather_day_index = 0

# ★ 新增：亮度、漂移、上次同步时间
brightness = 1023
drift_per_day = 0.0
last_sync_unix = 0

# 页面状态
screensaver_mode = False
screensaver_pos = 8
screensaver_last = 0
SCREENSAVER_TIMEOUT = 60000   # 60 秒无操作进入屏保
alarm_last_note_idx = -1
settings_selected = 0    # 0=设置时间 1=连接WiFi 2=亮度
device_info_mode = False
device_info_scroll = 0
current_page = 0
alarm_selected = 0
edit_mode = False
edit_hour = 0
edit_minute = 0
edit_field = 0
edit_stage = 0
weekday_cursor = 0
edit_days = [1,1,1,1,1,1,1]

menu_mode = False
menu_selected = 0

calendar_year = 2026
calendar_month = 9

auto_mode = True
last_user_action_time = time.ticks_ms()
auto_page_timer = time.ticks_ms()

alarm_ringing = False
alarm_screen_shown = False
alarm_ring_start = 0
last_alarm_trigger_minute = -1
alarm_screen_drawn = False

# ---------- 闹钟旋律 ----------

melody = [
    # ① Doe, a deer, a female deer
    (262, 750), (294, 250),
    (330, 750), (262, 250),
    (330, 500), (262, 500),
    (330, 1000),

    # ② Ray, a drop of golden sun
    (294, 750), (330, 250),
    (349, 250), (349, 250), (330, 250), (294, 250),
    (349, 1000),
    (349, 1000),

    # ③ Me, a name I call myself
    (330, 750), (349, 250),
    (392, 750), (330, 250),
    (392, 500), (330, 500),
    (392, 1000),

    # ④ Far, a long, long way to run
    (349, 750), (392, 250),
    (440, 250), (440, 250), (392, 250), (349, 250),
    (440, 1000),
    (440, 1000),

    # ⑤ Sew, a needle pulling thread
    (392, 750), (523, 250),
    (587, 250), (659, 250), (698, 250), (784, 250),
    (880, 1000),
    (880, 1000),

    # ⑥ La, a note to follow Sew
    (440, 750), (587, 250),
    (659, 250), (698, 250), (784, 250), (880, 250),
    (988, 1000),
    (988, 1000),

    # ⑦ Tea, a drink with jam and bread
    (494, 750), (659, 250),
    (698, 250), (784, 250), (880, 250), (988, 250),
    (523, 1000),
    (523, 1000),

    # ⑧ That will bring us back to Do
    (523, 250), (494, 250), (440, 250), (392, 250),
    (349, 250), (330, 250), (294, 250), (262, 250),

    # ⑨ oh-oh-oh 尾句
    (0,   250), (262, 250), (294, 250), (330, 250),
    (349, 250), (392, 250), (440, 250), (494, 250),
    (523, 1000),
    (392, 500), (262, 500), (523, 500), (0, 500),
]
# ---------- 农历数据表 1900-2100 ----------
LUNAR_INFO = [
    0x04bd8,0x04ae0,0x0a570,0x054d5,0x0d260,0x0d950,0x16554,0x056a0,0x09ad0,0x055d2,
    0x04ae0,0x0a5b6,0x0a4d0,0x0d250,0x1d255,0x0b540,0x0d6a0,0x0ada2,0x095b0,0x14977,
    0x04970,0x0a4b0,0x0b4b5,0x06a50,0x06d40,0x1ab54,0x02b60,0x09570,0x052f2,0x04970,
    0x06566,0x0d4a0,0x0ea50,0x06e95,0x05ad0,0x02b60,0x186e3,0x092e0,0x1c8d7,0x0c950,
    0x0d4a0,0x1d8a6,0x0b550,0x056a0,0x1a5b4,0x025d0,0x092d0,0x0d2b2,0x0a950,0x0b557,
    0x06ca0,0x0b550,0x15355,0x04da0,0x0a5b0,0x14573,0x052b0,0x0a9a8,0x0e950,0x06aa0,
    0x0aea6,0x0ab50,0x04b60,0x0aae4,0x0a570,0x05260,0x0f263,0x0d950,0x05b57,0x056a0,
    0x096d0,0x04dd5,0x04ad0,0x0a4d0,0x0d4d4,0x0d250,0x0d558,0x0b540,0x0b6a0,0x195a6,
    0x095b0,0x049b0,0x0a974,0x0a4b0,0x0b27a,0x06a50,0x06d40,0x0af46,0x0ab60,0x09570,
    0x04af5,0x04970,0x064b0,0x074a3,0x0ea50,0x06b58,0x055c0,0x0ab60,0x096d5,0x092e0,
    0x0c960,0x0d954,0x0d4a0,0x0da50,0x07552,0x056a0,0x0abb7,0x025d0,0x092d0,0x0cab5,
    0x0a950,0x0b4a0,0x0baa4,0x0ad50,0x055d9,0x04ba0,0x0a5b0,0x15176,0x052b0,0x0a930,
    0x07954,0x06aa0,0x0ad50,0x05b52,0x04b60,0x0a6e6,0x0a4e0,0x0d260,0x0ea65,0x0d530,
    0x05aa0,0x076a3,0x096d0,0x04afb,0x04ad0,0x0a4d0,0x1d0b6,0x0d250,0x0d520,0x0dd45,
    0x0b5a0,0x056d0,0x055b2,0x049b0,0x0a577,0x0a4b0,0x0aa50,0x1b255,0x06d20,0x0ada0,
    0x14b63,0x09370,0x049f8,0x04970,0x064b0,0x168a6,0x0ea50,0x06b20,0x1a6c4,0x0aae0,
    0x0a2e0,0x0d2e3,0x0c960,0x0d557,0x0d4a0,0x0da50,0x05d55,0x056a0,0x0a6d0,0x055d4,
    0x052d0,0x0a9b8,0x0a950,0x0b4a0,0x0b6a6,0x0ad50,0x055a0,0x0aba4,0x0a5b0,0x052b0,
    0x0b273,0x06930,0x07337,0x06aa0,0x0ad50,0x14b55,0x04b60,0x0a570,0x054e4,0x0d160,
    0x0e968,0x0d520,0x0daa0,0x16aa6,0x056d0,0x04ae0,0x0a9d4,0x0a2d0,0x0d150,0x0f252,
    0x0d520,
]

LUNAR_MONTH_NAMES = ["正","二","三","四","五","六","七","八","九","十","冬","腊"]
LUNAR_DAY_NAMES = ["初一","初二","初三","初四","初五","初六","初七","初八","初九","初十",
                   "十一","十二","十三","十四","十五","十六","十七","十八","十九","二十",
                   "廿一","廿二","廿三","廿四","廿五","廿六","廿七","廿八","廿九","三十"]

def _days_from_1900(year, month, day):
    """从 1900-01-01 算起的天数（避免用 time.mktime 跨时区出问题）"""
    days = 0
    for y in range(1900, year):
        days += 366 if ((y % 4 == 0 and y % 100 != 0) or y % 400 == 0) else 365
    md = [31,28,31,30,31,30,31,31,30,31,30,31]
    for m in range(1, month):
        days += md[m-1]
        if m == 2 and ((year % 4 == 0 and year % 100 != 0) or year % 400 == 0):
            days += 1
    days += day - 1
    return days

def _lunar_year_days(y):
    s = 348
    i = 0x8000
    while i > 0x8:
        if LUNAR_INFO[y - 1900] & i:
            s += 1
        i >>= 1
    return s + _lunar_leap_days(y)

def _lunar_leap_month(y):
    return LUNAR_INFO[y - 1900] & 0xf

def _lunar_leap_days(y):
    if _lunar_leap_month(y):
        return 30 if (LUNAR_INFO[y - 1900] & 0x10000) else 29
    return 0

def _lunar_month_days(y, m):
    return 30 if (LUNAR_INFO[y - 1900] & (0x10000 >> m)) else 29

def solar_to_lunar(year, month, day):
    """公历转农历，返回 (lunar_year, lunar_month, lunar_day, is_leap)"""
    offset = _days_from_1900(year, month, day) - 30   # 1900-01-31 是庚子年正月初一

    y = 1900
    while y < 2101:
        yd = _lunar_year_days(y)
        if offset < yd:
            break
        offset -= yd
        y += 1

    leap = _lunar_leap_month(y)
    m = 1
    while m <= 12:
        days = _lunar_month_days(y, m)
        if offset < days:
            return y, m, offset + 1, False
        offset -= days

        if leap == m:
            days = _lunar_leap_days(y)
            if offset < days:
                return y, m, offset + 1, True
            offset -= days
        m += 1

    return y, m, offset + 1, False

def format_lunar(year, month, day):
    """返回 '农历X月X' 的中文串，例如 '五月廿三' 或 '闰六月初五'"""
    ly, lm, ld, is_leap = solar_to_lunar(year, month, day)
    prefix = "闰" if is_leap else ""
    mname = LUNAR_MONTH_NAMES[lm - 1]
    dname = LUNAR_DAY_NAMES[ld - 1]
    return "{}月{}".format(prefix + mname, dname)
# ---------- 节假日表 ----------
SOLAR_HOLIDAYS = {
    (1, 1): "元旦", (2, 14): "情人节", (3, 8): "妇女节", (3, 12): "植树节",
    (4, 1): "愚人节", (5, 1): "劳动节", (5, 4): "青年节", (6, 1): "儿童节",
    (7, 1): "建党节", (8, 1): "建军节", (9, 10): "教师节",
    (10, 1): "国庆节", (12, 25): "圣诞节",
}

# 农历主要节日的公历日期（春节/元宵/端午/中秋），每年核对一次即可
LUNAR_HOLIDAYS = {
    (2025, 1, 29): "春节", (2025, 2, 12): "元宵", (2025, 5, 31): "端午", (2025, 10, 6): "中秋",
    (2026, 2, 17): "春节", (2026, 3, 3): "元宵", (2026, 6, 19): "端午", (2026, 9, 25): "中秋",
    (2027, 2, 6): "春节", (2027, 2, 20): "元宵", (2027, 6, 9): "端午", (2027, 9, 15): "中秋",
    (2028, 1, 26): "春节", (2028, 2, 9): "元宵", (2028, 5, 28): "端午", (2028, 10, 3): "中秋",
    (2029, 2, 13): "春节", (2029, 2, 27): "元宵", (2029, 6, 16): "端午", (2029, 9, 22): "中秋",
    (2030, 2, 3): "春节", (2030, 2, 17): "元宵", (2030, 6, 5): "端午", (2030, 9, 12): "中秋",
}

def get_next_holiday(year, month, day):
    """返回 (剩余天数, 节日名)，最近的一个节日"""
    today = time.mktime((year, month, day, 0, 0, 0, 0, 0))
    best_days = 9999
    best_name = None

    # 公历节日（循环到明年）
    for (m, d), name in SOLAR_HOLIDAYS.items():
        for y in (year, year + 1):
            try:
                t = time.mktime((y, m, d, 0, 0, 0, 0, 0))
            except:
                continue
            diff = (t - today) // 86400
            if 0 <= diff < best_days:
                best_days = diff
                best_name = name

    # 农历节日（固定日期）
    for (y, m, d), name in LUNAR_HOLIDAYS.items():
        try:
            t = time.mktime((y, m, d, 0, 0, 0, 0, 0))
        except:
            continue
        diff = (t - today) // 86400
        if 0 <= diff < best_days:
            best_days = diff
            best_name = name

    return best_days, best_name
# ★ 大数字字体（5x7）
DIGIT_FONT = {
    '0': [0x0E,0x11,0x11,0x11,0x11,0x11,0x0E],
    '1': [0x04,0x0C,0x04,0x04,0x04,0x04,0x0E],
    '2': [0x0E,0x11,0x01,0x02,0x04,0x08,0x1F],
    '3': [0x1F,0x02,0x04,0x02,0x01,0x11,0x0E],
    '4': [0x02,0x06,0x0A,0x12,0x1F,0x02,0x02],
    '5': [0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E],
    '6': [0x06,0x08,0x10,0x1E,0x11,0x11,0x0E],
    '7': [0x1F,0x01,0x02,0x04,0x08,0x08,0x08],
    '8': [0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E],
    '9': [0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C],
    ':': [0x00,0x04,0x04,0x00,0x04,0x04,0x00],
}

def draw_big_text(text, x, y, scale, color):
    cx = x
    for ch in text:
        glyph = DIGIT_FONT.get(ch)
        if glyph is None:
            cx += 6 * scale
            continue
        for row in range(7):
            bits = glyph[row]
            for col in range(5):
                if bits & (0x10 >> col):
                    display.fill_rect(cx + col*scale, y + row*scale, scale, scale, color)
        cx += 6 * scale

# ---------- 加载/保存 ----------
def load_data():
    global alarms, countdown_target, calendar_year, calendar_month, weather_data
    global brightness, drift_per_day, last_sync_unix
    try:
        with open(DATA_FILE, 'r') as f:
            data = ujson.load(f)
            alarms = data.get("alarms", [])
            for a in alarms:
                if 'days' not in a:
                    a['days'] = [1,1,1,1,1,1,1]
            countdown_target = data.get("countdown", countdown_target)
            weather_data = data.get("weather", [])
            brightness = data.get("brightness", 1023)
            drift_per_day = data.get("drift_per_day", 0.0)
            last_sync_unix = data.get("last_sync_unix", 0)
            t = data.get("time", (2026,9,5,12,0,0))
            rtc.datetime((t[0],t[1],t[2],0,t[3],t[4],t[5],0))
    except:
        rtc.datetime((2026,9,5,12,0,0,0,0))
    dt = rtc.datetime()
    calendar_year = dt[0]
    calendar_month = dt[1]

def save_data():
    dt = rtc.datetime()
    data = {
        "time": (dt[0],dt[1],dt[2],dt[4],dt[5],dt[6]),
        "alarms": alarms,
        "countdown": countdown_target,
        "weather": weather_data,
        "brightness": brightness,
        "drift_per_day": drift_per_day,
        "last_sync_unix": last_sync_unix,
    }
    with open(DATA_FILE, 'w') as f:
        ujson.dump(data, f)

load_data()
backlight.duty(brightness)

# ---------- 摇杆 ----------
def read_joystick():
    x = joy_x.read()
    y = joy_y.read()
    sw = joy_sw.value()
    time.sleep_ms(1)
    if sw == 0:
        time.sleep_ms(20)
        if joy_sw.value() == 0:
            while joy_sw.value() == 0:
                time.sleep_ms(10)
            return 'press'
    if y > 3000: return 'up'
    if y < 1000: return 'down'
    if x < 1000: return 'left'
    if x > 3000: return 'right'
    return None

def beep(freq=1000, ms=100):
    buzzer.freq(freq)
    buzzer.duty(512)
    time.sleep_ms(ms)
    buzzer.duty(0)

# ---------- 电池电压 ----------
def read_battery_voltage():
    total = 0
    for _ in range(10):
        total += battery_adc.read()
    avg = total / 10
    vout = avg / 4095 * 3.3
    vin = vout * 5.62   # 根据之前校准得出的比例
    return vin

BATT_TABLE = [
    (4.20, 100), (4.10, 90), (4.00, 80), (3.93, 70), (3.87, 60),
    (3.82, 50), (3.79, 40), (3.77, 30), (3.74, 20), (3.68, 10),
    (3.50, 5), (3.30, 1), (3.00, 0),
]

def battery_percent(v):
    if v >= BATT_TABLE[0][0]: return 100
    if v <= BATT_TABLE[-1][0]: return 0
    for i in range(len(BATT_TABLE) - 1):
        v_hi, p_hi = BATT_TABLE[i]
        v_lo, p_lo = BATT_TABLE[i + 1]
        if v_lo <= v <= v_hi:
            ratio = (v - v_lo) / (v_hi - v_lo)
            return int(p_lo + ratio * (p_hi - p_lo))
    return 0

# ★ 6. 时间漂移补偿
def read_rtc_corrected():
    dt = rtc.datetime()
    if drift_per_day != 0 and last_sync_unix > 0:
        try:
            unix_t = time.mktime((dt[0],dt[1],dt[2],dt[4],dt[5],dt[6],0,0))
            days = (unix_t - last_sync_unix) / 86400
            unix_t -= int(drift_per_day * days)
            tm = time.localtime(unix_t)
            return (tm[0],tm[1],tm[2],tm[6],tm[3],tm[4],tm[5],0)
        except:
            pass
    return dt

# ---------- 闹钟检测 ----------
def check_alarms():
    global alarm_ringing, alarm_ring_start, last_alarm_trigger_minute
    dt = read_rtc_corrected()
    current_minute = dt[4] * 60 + dt[5]
    weekday = dt[3]
    for alarm in alarms:
        if alarm['enabled']:
            alarm_minute = alarm['hour'] * 60 + alarm['minute']
            days = alarm.get('days', [1,1,1,1,1,1,1])
            if alarm_minute == current_minute and days[weekday] and last_alarm_trigger_minute != current_minute:
                last_alarm_trigger_minute = current_minute
                alarm_ringing = True
                alarm_ring_start = time.ticks_ms()
                alarm_screen_shown = False   # ★ 加这一行
                break

# ★ 7. 闹钟错过提醒
def check_missed_alarms():
    global alarm_ringing, alarm_ring_start, last_alarm_trigger_minute
    dt = read_rtc_corrected()
    current_minute = dt[4] * 60 + dt[5]
    weekday = dt[3]
    for alarm in alarms:
        if alarm['enabled']:
            alarm_minute = alarm['hour'] * 60 + alarm['minute']
            days = alarm.get('days', [1,1,1,1,1,1,1])
            diff = current_minute - alarm_minute
            if 1 <= diff <= 5 and days[weekday]:
                alarm_ringing = True
                alarm_ring_start = time.ticks_ms()
                alarm_screen_shown = False   # ★ 加这一行
                last_alarm_trigger_minute = alarm_minute
                print("补响闹钟:", alarm['hour'], ":", alarm['minute'])
                return

# ---------- 字库绘制 ----------
def get_chinese_bitmap(ch):
    try:
        code = ch.encode('utf-8')
        if len(code) != 3: return None
        cp = ((code[0]&0x0F)<<12)|((code[1]&0x3F)<<6)|(code[2]&0x3F)
        f = open('font16.bin','rb')
        f.seek(0)
        header = f.read(4)
        n = header[0]|(header[1]<<8)|(header[2]<<16)|(header[3]<<24)
        low, high = 0, n-1
        while low <= high:
            mid = (low+high)//2
            f.seek(4+mid*4)
            cp_bytes = f.read(4)
            cp_mid = cp_bytes[0]|(cp_bytes[1]<<8)|(cp_bytes[2]<<16)|(cp_bytes[3]<<24)
            if cp_mid == cp:
                f.seek(4+4*n+mid*32)
                return f.read(32)
            elif cp_mid < cp: low = mid+1
            else: high = mid-1
        f.close()
    except:
        pass
    return None

def draw_chinese_string(text,x,y,color):
    dx = x
    for ch in text:
        bitmap = get_chinese_bitmap(ch)
        if bitmap:
            for row in range(16):
                word = (bitmap[row*2]<<8)|bitmap[row*2+1]
                for col in range(16):
                    if word & (0x8000>>col):
                        display.pixel(dx+col, y+row, color)
            dx += 16
        else:
            display.text(ch, dx, y, color)
            dx += 8
# ---------- 8x8 小号中文字 ----------
def draw_chinese_string_small(text, x, y, color):
    dx = x
    for ch in text:
        bitmap = get_chinese_bitmap(ch)
        if bitmap:
            for row in range(0, 16, 2):
                word  = (bitmap[row*2]   << 8) | bitmap[row*2+1]
                word2 = (bitmap[(row+1)*2] << 8) | bitmap[(row+1)*2+1]
                for col in range(0, 16, 2):
                    b1 = (word  >> (15-col)) & 1
                    b2 = (word  >> (14-col)) & 1
                    b3 = (word2 >> (15-col)) & 1
                    b4 = (word2 >> (14-col)) & 1
                    if b1 or b2 or b3 or b4:
                        display.pixel(dx + col//2, y + row//2, color)
            dx += 8
        else:
            display.text(ch, dx, y, color)
            dx += 8
            
def draw_header():
    display.fill_rect(125, 0, 35, 20, st7735.BLACK)
    display.text("{}/{}".format(current_page+1, 6), 128, 55, st7735.YELLOW)

# ---------- 图片显示 ----------
def draw_image(filename, x0=0, y0=0, w=160, h=128, src_w=160, src_h=128):
    try:
        with open(filename, 'rb') as f:
            last_sy = -1
            row_buf = None
            for dy in range(h):
                sy = dy * src_h // h
                if sy != last_sy:
                    f.seek(sy * src_w * 2)
                    row_buf = f.read(src_w * 2)
                    last_sy = sy
                for dx in range(w):
                    sx = dx * src_w // w
                    hi = row_buf[sx * 2]
                    lo = row_buf[sx * 2 + 1]
                    color = (hi << 8) | lo
                    display.pixel(x0 + dx, y0 + dy, color)
    except Exception as e:
        print("图片显示失败:", e)

def draw_corner_icon():
    draw_image('wallpaper.bin', x0=126, y0=94, w=32, h=32)

def draw_check_mark(x, y, color):
    pts = [
        (0,4),(1,5),(2,6),(3,7),(4,8),
        (0,5),(1,6),(2,7),(3,8),(4,9),
        (5,7),(6,6),(7,5),(8,4),(9,3),
        (5,8),(6,7),(7,6),(8,5),(9,4),
    ]
    for dx, dy in pts:
        display.pixel(x+dx, y+dy, color)

# ---------- 开机 Logo ----------
def draw_logo_screen():
    display.fill(st7735.BLACK)
    display.show()

    # 1. 图片逐行刷出（从上往下）
    try:
        with open('logo.bin', 'rb') as f:
            for dy in range(80):
                sy = dy * 128 // 80
                f.seek(sy * 160 * 2)
                row = f.read(160 * 2)
                for dx in range(100):
                    sx = dx * 160 // 100
                    hi = row[sx * 2]
                    lo = row[sx * 2 + 1]
                    color = (hi << 8) | lo
                    display.pixel(30 + dx, 5 + dy, color)
                if dy % 8 == 0:
                    display.show()
    except Exception as e:
        print("Logo 显示失败:", e)

    # 2. 播放开机音效（Do-Mi-Sol-Do）
    for freq, dur in [(262, 150), (330, 150), (392, 150), (523, 300)]:
        buzzer.freq(freq)
        buzzer.duty(700)
        time.sleep_ms(dur)
        buzzer.duty(0)
        time.sleep_ms(40)

    # 3. 显示文字
    draw_chinese_string("Givera嘉雅科技", 24, 92, st7735.WHITE)
    draw_chinese_string("版本号", 45, 114, st7735.YELLOW)
    display.text("V1.0.0", 93, 118, st7735.YELLOW)
    display.show()
    time.sleep(1.5)

# ---------- ★ 1. 时间页大号时间 + 3. 低电量警告 ----------
def draw_time_page():
    display.fill(st7735.BLACK)
    draw_header()
    dt = read_rtc_corrected()
    date_str = "{:04d}-{:02d}-{:02d}".format(dt[0],dt[1],dt[2])
    display.text(date_str, 30, 8, st7735.CYAN)

    # ★ 农历日期（青绿色，显示在公历下面）
    try:
        lunar_str = format_lunar(dt[0], dt[1], dt[2])
        draw_chinese_string(lunar_str, 8, 22, st7735.GREEN)
    except Exception as e:
        print("农历计算失败:", e)

    # ★ 节日倒计时（红色，显示在农历右侧）
    days, name = get_next_holiday(dt[0], dt[1], dt[2])
    if name:
        if days == 0:
            text = "今天" + name
        elif days == 1:
            text = "明天" + name
        elif days <= 99:
            text = "还有{}天{}".format(days, name)
        else:
            text = ""
        if text:
            draw_chinese_string(text, 8, 40, st7735.RED)

    time_str = "{:02d}:{:02d}:{:02d}".format(dt[4],dt[5],dt[6])
    draw_big_text(time_str, 8, 62, 3, st7735.WHITE)

    weekdays = ["周一","周二","周三","周四","周五","周六","周日"]
    draw_chinese_string(weekdays[dt[3]], 8, 100, st7735.YELLOW)

    v = read_battery_voltage()
    pct = battery_percent(v)
    if pct <= 15:
        if (time.ticks_ms() // 500) % 2 == 0:
            draw_chinese_string("电量低", 72, 100, st7735.RED)

    draw_corner_icon()
    display.show()
def draw_alarm_page():
    display.fill(st7735.BLACK)
    draw_header()
    draw_chinese_string("闹钟", 5, 10, st7735.YELLOW)
    y = 35
    for i, alarm in enumerate(alarms):
        state = "开" if alarm['enabled'] else "关"
        days = alarm.get('days', [1,1,1,1,1,1,1])
        if all(days): day_str = "每天"
        elif not any(days): day_str = "无"
        else:
            wd_char = ["一","二","三","四","五","六","日"]
            day_str = "".join([wd_char[j] for j in range(7) if days[j]])
        text = "{:02d}:{:02d} {} {}".format(alarm['hour'], alarm['minute'], state, day_str)
        if i == alarm_selected:
            display.fill_rect(5, y-2, 150, 18, st7735.WHITE)
            display.text(text, 5, y, st7735.BLACK)
        else:
            display.text(text, 5, y, st7735.WHITE)
        y += 20
    draw_chinese_string("新建", 5, y+5, st7735.GREEN)
    draw_corner_icon()
    display.show()

def draw_countdown_page():
    display.fill(st7735.BLACK)
    draw_header()
    draw_chinese_string("倒计时", 5, 10, st7735.YELLOW)
    draw_chinese_string("距离高考仅剩", 5, 35, st7735.YELLOW)
    target = time.mktime((countdown_target[0],countdown_target[1],countdown_target[2],
                          countdown_target[3],countdown_target[4],countdown_target[5],0,0))
    remaining = target - time.time()
    if remaining < 0: remaining = 0
    days = remaining // 86400
    hours = (remaining % 86400) // 3600
    minutes = (remaining % 3600) // 60
    seconds = remaining % 60
    anim_cs = time.ticks_ms() % 100
    display.text("{}".format(days), 5, 55, st7735.GREEN)
    draw_chinese_string("天", 40, 55, st7735.GREEN)
    display.text("{}".format(hours), 5, 75, st7735.WHITE)
    draw_chinese_string("时", 25, 75, st7735.WHITE)
    display.text("{}".format(minutes), 45, 75, st7735.WHITE)
    draw_chinese_string("分", 65, 75, st7735.WHITE)
    display.text("{:02d}.{:02d}".format(seconds, anim_cs), 85, 75, st7735.WHITE)
    draw_chinese_string("秒", 130, 75, st7735.WHITE)
    draw_corner_icon()
    display.show()

def draw_calendar_page():
    display.fill(st7735.BLACK)
    draw_header()
    dt = rtc.datetime()
    year = calendar_year
    month = calendar_month
    display.text("{:04d}-{:02d}".format(year, month), 5, 5, st7735.CYAN)
    weekdays = ["一","二","三","四","五","六","日"]
    x = 5
    for wd in weekdays:
        draw_chinese_string(wd, x, 25, st7735.YELLOW)
        x += 18
    first_day = time.mktime((year, month, 1, 0, 0, 0, 0, 0))
    first_weekday = time.localtime(first_day)[6]
    if month == 12:
        next_month, next_year = 1, year + 1
    else:
        next_month, next_year = month + 1, year
    days_in_month = time.mktime((next_year, next_month, 1, 0, 0, 0, 0, 0)) - first_day
    days_in_month = days_in_month // 86400
    today = dt[2] if dt[1] == month and dt[0] == year else None
    y = 45
    col = first_weekday
    for day in range(1, days_in_month + 1):
        x = 5 + col * 18
        if day == today:
            display.fill_rect(x - 2, y - 2, 16, 16, st7735.WHITE)
            display.text(str(day), x, y, st7735.BLACK)
        else:
            display.text(str(day), x, y, st7735.WHITE)
        col += 1
        if col > 6:
            col = 0
            y += 16
            if y > 120: break
    draw_corner_icon()
    display.show()

# ---------- ★ 4. 设置页加入亮度 ----------
def draw_settings_page():
    display.fill(st7735.BLACK)
    draw_header()
    draw_chinese_string("设置", 5, 4, st7735.YELLOW)

    options = ["设置时间", "连接WiFi", "亮度", "设备信息"]
    y = 24
    for i, opt in enumerate(options):
        if i == settings_selected:
            display.fill_rect(5, y-3, 110, 20, st7735.WHITE)
            draw_chinese_string(opt, 10, y, st7735.BLACK)
        else:
            draw_chinese_string(opt, 10, y, st7735.WHITE)
        y += 20

    # 电压电量放最底部
    v = read_battery_voltage()
    pct = battery_percent(v)
    if pct >= 60: c = st7735.GREEN
    elif pct >= 30: c = st7735.YELLOW
    else: c = st7735.RED
    display.text("{:.2f}V {}%".format(v, pct), 5, 112, c)

    draw_corner_icon()
    display.show()
# ---------- 设备信息数据 ----------
def get_device_info_list():
    info = []
    info.append(("设备名",   "Givera Clock"))
    info.append(("制造商",   "Givera"))
    info.append(("型号",     "GC-2026"))
    info.append(("固件",     "V1.0.0"))
    info.append(("内核",     "MicroPython"))
    try:
        uname = os.uname()
        info.append(("系统",   uname.release))
        info.append(("平台",   uname.machine))
    except:
        pass
    info.append(("芯片",     "ESP32-S3"))
    info.append(("主频",     "240MHz"))
    info.append(("架构",     "Xtensa LX7"))
    info.append(("无线",     "WiFi+BT5"))
    try:
        gc.collect()
        info.append(("空闲内存", "{}KB".format(gc.mem_free() // 1024)))
    except:
        pass
    try:
        st = os.statvfs('/')
        info.append(("Flash", "{}MB".format(st[0] * st[2] // 1024 // 1024)))
        info.append(("可用",  "{}KB".format(st[0] * st[3] // 1024)))
    except:
        pass
    info.append(("屏幕",     "ST7735"))
    info.append(("尺寸",     "1.8inch"))
    info.append(("分辨率",   "160x128"))
    info.append(("颜色",     "RGB565"))
    try:
        v = read_battery_voltage()
        pct = battery_percent(v)
        info.append(("电池",     "18650"))
        info.append(("电压",     "{:.2f}V".format(v)))
        info.append(("电量",     "{}%".format(pct)))
    except:
        pass
    try:
        wlan = network.WLAN(network.STA_IF)
        if wlan.isconnected():
            info.append(("WiFi", "已连接"))
            info.append(("IP",   wlan.ifconfig()[0]))
        else:
            info.append(("WiFi", "未连接"))
        try:
            mac = wlan.config('mac')
            mac_str = ':'.join(['%02X' % b for b in mac])
            info.append(("MAC", mac_str))
        except:
            pass
    except:
        pass
    uptime_ms = time.ticks_ms()
    info.append(("运行", "{}时{}分".format(uptime_ms // 3600000,
                                            (uptime_ms % 3600000) // 60000)))
    if last_sync_unix > 0:
        tm = time.localtime(last_sync_unix)
        info.append(("同步", "{:02d}-{:02d} {:02d}:{:02d}".format(tm[1], tm[2], tm[3], tm[4])))
    else:
        info.append(("同步", "从未"))
    info.append(("闹钟数",   "{}".format(len(alarms))))
    info.append(("序列号",   "GC26S30001"))
    info.append(("生产日期", "2026-01"))
    info.append(("保修期",   "12个月"))
    info.append(("技术支援", "givera.qzz.io"))
    info.append(("版权",     "(C)2026 Givera"))
    return info

def draw_device_info_page():
    display.fill(st7735.BLACK)
    draw_header()
    draw_chinese_string("设备信息", 5, 2, st7735.YELLOW)

    info = get_device_info_list()
    line_h = 22                        # 每项占 22px（标签行 + 值行）
    top = 22
    visible_h = 126 - top
    max_lines = visible_h // line_h    # 约 4 项
    total = len(info)

    # 右上角页码
    display.text("{}/{}".format(device_info_scroll + 1, total), 108, 6, st7735.YELLOW)

    start = device_info_scroll
    y = top
    for i in range(start, min(start + max_lines, total)):
        label, value = info[i]
        # 第一行：中文标签（青色）
        draw_chinese_string_small(label, 2, y, st7735.CYAN)
        # 第二行：完整值（白色），从最左开始，整行宽度
        if value:
            draw_chinese_string_small(value, 8, y + 11, st7735.WHITE)
        y += line_h

    draw_corner_icon()
    display.show()
def draw_weather_page():
    display.fill(st7735.BLACK)
    draw_header()
    if not weather_data:
        draw_chinese_string("暂无天气数据", 5, 40, st7735.YELLOW)
        draw_chinese_string("请连接WiFi更新", 5, 65, st7735.WHITE)
        display.show()
        return
    idx = weather_day_index if weather_day_index < len(weather_data) else 0
    date_str, tmax, tmin, text, hum = weather_data[idx]
    draw_chinese_string("天气", 5, 10, st7735.YELLOW)
    display.text(date_str, 5, 30, st7735.CYAN)
    display.text("{}~{}C".format(tmin, tmax), 5, 50, st7735.GREEN)
    draw_chinese_string(text, 5, 70, st7735.WHITE)
    draw_chinese_string("湿度", 5, 90, st7735.WHITE)
    display.text("{}%".format(hum), 45, 90, st7735.YELLOW)
    display.text("{}/{}".format(idx + 1, len(weather_data)), 5, 110, st7735.YELLOW)
    draw_corner_icon()
    display.show()

# ---------- ★ 5. 星期页加工作日/周末快捷 ----------
def draw_edit_page():
    display.fill(st7735.BLACK)
    draw_header()
    if current_page == 1:
        if edit_stage == 0:
            draw_chinese_string("设置闹钟", 5, 5, st7735.YELLOW)
            x = 30
            if edit_field == 0:
                display.fill_rect(x, 28, 25, 20, st7735.WHITE)
                display.text("{:02d}".format(edit_hour), x+2, 30, st7735.BLACK)
            else:
                display.text("{:02d}".format(edit_hour), x+2, 30, st7735.WHITE)
            display.text(":", x+30, 30, st7735.WHITE)
            x += 50
            if edit_field == 1:
                display.fill_rect(x, 28, 25, 20, st7735.WHITE)
                display.text("{:02d}".format(edit_minute), x+2, 30, st7735.BLACK)
            else:
                display.text("{:02d}".format(edit_minute), x+2, 30, st7735.WHITE)

            options = ["时", "分", "星期", "保存"]
            for i, opt in enumerate(options):
                bx = 9 + i * 36
                by = 80
                if i == edit_field:
                    display.fill_rect(bx, by, 34, 22, st7735.CYAN)
                    draw_chinese_string(opt, bx + (34 - len(opt)*16)//2, by+3, st7735.BLACK)
                else:
                    display.rect(bx, by, 34, 22, st7735.WHITE)
                    draw_chinese_string(opt, bx + (34 - len(opt)*16)//2, by+3, st7735.WHITE)
        else:
            # 星期选择（含工作日/周末/保存）
            week_names = ["一", "二", "三", "四", "五", "六", "日"]
            # 第一行 7 个星期
            for i in range(7):
                bx = 9 + i * 20
                by = 25
                if i == weekday_cursor:
                    display.rect(bx, by, 18, 38, st7735.YELLOW)
                    display.rect(bx+1, by+1, 16, 36, st7735.YELLOW)
                else:
                    display.rect(bx, by, 18, 38, st7735.WHITE)
                draw_chinese_string(week_names[i], bx+1, by+2, st7735.WHITE)
                cb_x = bx + 2
                cb_y = by + 20
                display.rect(cb_x, cb_y, 14, 14, st7735.WHITE)
                if edit_days[i]:
                    draw_check_mark(cb_x+2, cb_y+2, st7735.GREEN)
            # 第二行：工作日、周末、保存
            labels = ["工作日", "周末", "保存"]
            for k, lab in enumerate(labels):
                bx = 9 + k * 50
                by = 80
                cursor_idx = 7 + k
                if cursor_idx == weekday_cursor:
                    display.rect(bx, by, 46, 24, st7735.YELLOW)
                    display.rect(bx+1, by+1, 44, 22, st7735.YELLOW)
                else:
                    display.rect(bx, by, 46, 24, st7735.WHITE)
                if lab == "保存":
                    draw_chinese_string("保存", bx+7, by+4, st7735.CYAN)
                else:
                    draw_chinese_string(lab, bx-1, by+4, st7735.WHITE)
    elif current_page == 4:
        draw_chinese_string("设置时间", 5, 10, st7735.YELLOW)
        x = 30
        fields = [edit_hour, edit_minute]
        for i, val in enumerate(fields):
            if i == edit_field:
                display.fill_rect(x, 40, 25, 20, st7735.WHITE)
                display.text("{:02d}".format(val), x+2, 42, st7735.BLACK)
            else:
                display.text("{:02d}".format(val), x+2, 42, st7735.WHITE)
            if i == 0:
                display.text(":", x+30, 42, st7735.WHITE)
            x += 50
        display.text(":00", x+10, 42, st7735.WHITE)
    display.show()

def draw_alarm_menu():
    display.fill(st7735.BLACK)
    draw_header()
    draw_chinese_string("闹钟操作", 5, 10, st7735.YELLOW)
    if alarm_selected < len(alarms):
        option2 = "关闭" if alarms[alarm_selected]['enabled'] else "开启"
    else:
        option2 = "开启"
    options = ["编辑", option2, "删除", "取消"]
    y = 40
    for i, opt in enumerate(options):
        if i == menu_selected:
            display.fill_rect(5, y-2, 60, 18, st7735.WHITE)
            draw_chinese_string(opt, 5, y, st7735.BLACK)
        else:
            draw_chinese_string(opt, 5, y, st7735.WHITE)
        y += 25
    display.show()

# ---------- WMO 天气代码转中文 ----------
def wmo_to_text(code):
    if code == 0: return "晴"
    elif code in (1,2): return "多云"
    elif code == 3: return "阴"
    elif code in (45,48): return "雾"
    elif code in (51,53,55): return "毛毛雨"
    elif code in (56,57): return "冻雨"
    elif code in (61,63,65): return "雨"
    elif code in (66,67): return "冻雨"
    elif code in (71,73,75,77): return "雪"
    elif code in (80,81,82): return "阵雨"
    elif code in (85,86): return "阵雪"
    elif code in (95,96,99): return "雷雨"
    else: return "未知"

# ---------- 天气查询 ----------
def fetch_weather():
    global weather_data
    url = ("https://api.open-meteo.com/v1/forecast?"
           "latitude={}&longitude={}"
           "&daily=temperature_2m_max,temperature_2m_min,weathercode,relative_humidity_2m_max"
           "&timezone=Asia/Shanghai&forecast_days=10").format(WEATHER_LAT, WEATHER_LON)
    try:
        import urequests
        r = urequests.get(url)
        data = r.json()
        r.close()
        daily = data['daily']
        weather_data = []
        for i in range(len(daily['time'])):
            date = daily['time'][i]
            tmax = int(daily['temperature_2m_max'][i])
            tmin = int(daily['temperature_2m_min'][i])
            code = int(daily['weathercode'][i])
            hum  = int(daily['relative_humidity_2m_max'][i])
            weather_data.append((date, tmax, tmin, wmo_to_text(code), hum))
        print("天气查询成功，共", len(weather_data), "天")
        return True
    except Exception as e:
        print("天气查询失败:", e)
        return False

# ---------- WiFi 与时间同步 ----------
def connect_wifi():
    gc.collect()
    wlan = network.WLAN(network.STA_IF)
    wlan.active(False)
    time.sleep_ms(200)
    if not wlan.active(True):
        return None
    if wlan.isconnected():
        return wlan
    display.fill(st7735.BLACK)
    draw_chinese_string("正在连接 WiFi...", 10, 50, st7735.YELLOW)
    backlight.duty(0)   # ★ 连接时关背光，省 150mA
    display.show()
    backlight.duty(0)
    try:
        wlan.connect(WIFI_SSID, WIFI_PASSWORD)
        for _ in range(10):
            if wlan.isconnected():
                backlight.duty(brightness)
                display.fill(st7735.BLACK)
                draw_chinese_string("WiFi 已连接", 10, 50, st7735.GREEN)
                display.show()
                time.sleep(1)
                return wlan
            time.sleep_ms(500)
        backlight.duty(brightness)
        display.fill(st7735.BLACK)
        draw_chinese_string("WiFi 连接失败", 10, 50, st7735.RED)
        display.show()
        time.sleep(1)
        return None
    except OSError as e:
        backlight.duty(brightness)
        print("WiFi 连接异常:", e)
        return None

def sync_time():
    global drift_per_day, last_sync_unix
    wlan = connect_wifi()
    if wlan is None:
        return False
    try:
        display.fill(st7735.BLACK)
        draw_chinese_string("正在同步时间...", 10, 50, st7735.YELLOW)
        display.show()

        # 记录同步前的 RTC
        old_dt = rtc.datetime()
        try:
            old_unix = time.mktime((old_dt[0],old_dt[1],old_dt[2],old_dt[4],old_dt[5],old_dt[6],0,0))
        except:
            old_unix = 0

        ntptime.settime()
        time.sleep_ms(300)
        tm = time.localtime(time.time() + 8*3600)
        new_unix = time.mktime((tm[0],tm[1],tm[2],tm[3],tm[4],tm[5],0,0))

        # ★ 6. 时间漂移估算
        if last_sync_unix > 0 and old_unix > 0 and new_unix > last_sync_unix:
            real_elapsed = new_unix - last_sync_unix
            if real_elapsed > 3600:  # 至少 1 小时才有意义
                rtc_elapsed = old_unix - last_sync_unix
                drift = rtc_elapsed - real_elapsed
                drift_per_day = drift / (real_elapsed / 86400)
                print("漂移估算:", drift_per_day, "秒/天")
        last_sync_unix = new_unix

        rtc.datetime((tm[0], tm[1], tm[2], tm[6], tm[3], tm[4], tm[5], 0))

        display.fill(st7735.BLACK)
        draw_chinese_string("正在查询天气...", 10, 50, st7735.YELLOW)
        display.show()
        fetch_weather()

        display.fill(st7735.BLACK)
        draw_chinese_string("同步完成", 10, 50, st7735.GREEN)
        display.show()
        time.sleep(1)
        return True
    except Exception as e:
        print("同步失败:", e)
        return False
    finally:
        wlan.disconnect()
        #wlan.active(False)
        gc.collect()

# ---------- 启动菜单 ----------
def startup_menu():
    selected = 0
    while True:
        display.fill(st7735.BLACK)
        draw_chinese_string("是否连接网络校准时间?", 5, 20, st7735.WHITE)
        if selected == 0:
            display.fill_rect(30, 50, 40, 20, st7735.WHITE)
            draw_chinese_string("是", 35, 52, st7735.BLACK)
            draw_chinese_string("否", 75, 52, st7735.WHITE)
        else:
            draw_chinese_string("是", 35, 52, st7735.WHITE)
            display.fill_rect(70, 50, 40, 20, st7735.WHITE)
            draw_chinese_string("否", 75, 52, st7735.BLACK)
        display.show()
        action = read_joystick()
        if action == 'up' or action == 'down':
            selected = (selected + 1) % 2
            beep(2000, 30)
        elif action == 'press':
            beep(2500, 50)
            return selected == 0

# ---------- 启动流程 ----------
draw_logo_screen()

want_wifi = startup_menu()
if want_wifi:
    if sync_time():
        save_data()

# ★ 7. 开机检查错过的闹钟
check_missed_alarms()

last_user_action_time = time.ticks_ms()
auto_page_timer = time.ticks_ms()
auto_mode = True

# ---------- 主循环 ----------
while True:
    action = read_joystick()
    now = time.ticks_ms()
        # ---------- 设备信息页 ----------
    if device_info_mode:
        if action == 'up':
            if device_info_scroll > 0:
                device_info_scroll -= 1
                beep(2000, 30)
        elif action == 'down':
            total = len(get_device_info_list())
            line_h = 22
            max_lines = (126 - 22) // line_h
            max_scroll = max(0, total - max_lines)
            if device_info_scroll < max_scroll:
                device_info_scroll += 1
                beep(2000, 30)
        elif action == 'press':
            device_info_mode = False
            beep(2500, 50)
        draw_device_info_page()
        time.sleep(0.05)
        continue
        # ---------- 屏保 ----------
    if not alarm_ringing and not edit_mode and not menu_mode:
        if action is not None:
            if screensaver_mode:
                screensaver_mode = False
                backlight.duty(brightness)   # 恢复亮度
                last_user_action_time = now
            else:
                last_user_action_time = now
        else:
            if not screensaver_mode and time.ticks_diff(now, last_user_action_time) >= SCREENSAVER_TIMEOUT:
                screensaver_mode = True
                screensaver_pos = 8
                screensaver_last = now
                backlight.duty(200)          # 屏保变暗
            elif screensaver_mode:
                if time.ticks_diff(now, screensaver_last) >= 150:
                    screensaver_last = now
                    screensaver_pos += 4
                    if screensaver_pos > 160:
                        screensaver_pos = -80
                    display.fill(st7735.BLACK)
                    dt = rtc.datetime()
                    ts = "{:02d}:{:02d}".format(dt[4], dt[5])
                    draw_big_text(ts, screensaver_pos, 50, 4, st7735.WHITE)
                    display.show()
                time.sleep(0.02)
                continue

  
    # ---------- 闹钟响铃处理 ----------
    if alarm_ringing:
        # ★ 按键优先：只要有任何输入立刻停
        if action is not None:
            alarm_ringing = False
            buzzer.duty(0)
            action = None
            time.sleep(0.05)
            continue

        if time.ticks_diff(now, alarm_ring_start) >= 60000:
            alarm_ringing = False
            buzzer.duty(0)
        else:
            elapsed = time.ticks_diff(now, alarm_ring_start)
            total_duration = sum(dur for _, dur in melody)
            pos_in_loop = elapsed % total_duration

            current_pos = 0
            for freq, dur in melody:
                if pos_in_loop < current_pos + dur:
                    if freq == 0:
                        buzzer.duty(0)
                    else:
                        buzzer.freq(freq)
                        buzzer.duty(700)
                    break
                current_pos += dur

            # ★ 大字提示只显示一次，不再反复刷屏
            if not alarm_screen_shown:
                display.fill(st7735.BLACK)
                draw_chinese_string("闹钟", 48, 8, st7735.RED)
                dt = rtc.datetime()
                ts = "{:02d}:{:02d}".format(dt[4], dt[5])
                draw_big_text(ts, 20, 45, 5, st7735.WHITE)
                draw_chinese_string("按任意键停止", 8, 112, st7735.YELLOW)
                display.show()
                alarm_screen_shown = True

        time.sleep(0.02)
        continue    
    check_alarms()

    # ---------- 自动轮播 ----------
    if action is not None:
        last_user_action_time = now
        if auto_mode:
            auto_mode = False
    else:
        if auto_mode:
            if time.ticks_diff(now, auto_page_timer) >= 5000:
                if current_page == 0:
                    current_page = 2
                else:
                    current_page = 0
                auto_page_timer = now
        else:
            if time.ticks_diff(now, last_user_action_time) >= 30000:
                auto_mode = True
                edit_mode = False
                menu_mode = False
                current_page = 0
                auto_page_timer = now

    # ---------- 页面交互 ----------
    if not edit_mode and not menu_mode:
        if action == 'up':
            current_page = (current_page - 1) % 6
            beep(2000, 50)
        elif action == 'down':
            current_page = (current_page + 1) % 6
            beep(2000, 50)
        elif action == 'left':
            if current_page == 3:
                calendar_month -= 1
                if calendar_month < 1:
                    calendar_month = 12
                    calendar_year -= 1
                draw_calendar_page()
            elif current_page == 4:
                settings_selected = (settings_selected - 1) % 4
                beep(2000, 30)
            elif current_page == 5:
                if weather_data:
                    weather_day_index = (weather_day_index - 1) % len(weather_data)
            elif current_page == 1 and alarms:
                alarm_selected = (alarm_selected - 1) % len(alarms)
        elif action == 'right':
            if current_page == 3:
                calendar_month += 1
                if calendar_month > 12:
                    calendar_month = 1
                    calendar_year += 1
                draw_calendar_page()
            elif current_page == 4:
                settings_selected = (settings_selected + 1) % 4
                beep(2000, 30)
            elif current_page == 5:
                if weather_data:
                    weather_day_index = (weather_day_index + 1) % len(weather_data)
            elif current_page == 1 and alarms:
                alarm_selected = (alarm_selected + 1) % len(alarms)
        elif action == 'press':
            if current_page == 1:
                if alarm_selected < len(alarms):
                    menu_mode = True
                    menu_selected = 0
                    beep(2500,50)
                else:
                    edit_mode = True
                    edit_stage = 0
                    edit_hour = 8
                    edit_minute = 0
                    edit_field = 0
                    edit_days = [1,1,1,1,1,1,1]
                    weekday_cursor = 0
                    beep(2500, 50)
            elif current_page == 4:
                if settings_selected == 0:
                    dt = rtc.datetime()
                    edit_hour = dt[4]
                    edit_minute = dt[5]
                    edit_field = 0
                    edit_mode = True
                    beep(2500, 50)
                elif settings_selected == 1:
                    beep(2500, 50)
                    if sync_time():
                        save_data()
                        display.fill(st7735.BLACK)
                        draw_chinese_string("同步成功", 10, 50, st7735.GREEN)
                        draw_corner_icon()
                        display.show()
                    else:
                        display.fill(st7735.BLACK)
                        draw_chinese_string("同步失败", 10, 50, st7735.RED)
                        draw_corner_icon()
                        display.show()
                    time.sleep(1.5)
                elif settings_selected == 2:
                    # ★ 4. 循环亮度
                    global_b = None
                    if brightness >= 1023:
                        brightness_v = 768
                    elif brightness >= 768:
                        brightness_v = 512
                    elif brightness >= 512:
                        brightness_v = 256
                    else:
                        brightness_v = 1023
                    # 更新全局
                    import builtins
                    # 直接修改全局变量
                    globals()['brightness'] = brightness_v
                    backlight.duty(brightness_v)
                    save_data()
                    beep(2000, 50)
                elif settings_selected == 3:
                    # 进入设备信息页
                    device_info_mode = True
                    device_info_scroll = 0
                    beep(2500, 50)
    elif menu_mode:
        if action == 'press':
            if menu_selected == 0:
                edit_mode = True
                edit_stage = 0
                edit_hour = alarms[alarm_selected]['hour']
                edit_minute = alarms[alarm_selected]['minute']
                edit_field = 0
                edit_days = list(alarms[alarm_selected].get('days', [1,1,1,1,1,1,1]))
                weekday_cursor = 0
                menu_mode = False
            elif menu_selected == 1:
                alarms[alarm_selected]['enabled'] = not alarms[alarm_selected]['enabled']
                save_data()
                menu_mode = False
            elif menu_selected == 2:
                del alarms[alarm_selected]
                if alarm_selected >= len(alarms):
                    alarm_selected = max(0, len(alarms)-1)
                save_data()
                menu_mode = False
            elif menu_selected == 3:
                menu_mode = False
            beep(2500,50)
        elif action == 'up':
            menu_selected = (menu_selected - 1) % 4
        elif action == 'down':
            menu_selected = (menu_selected + 1) % 4
    else:  # edit_mode
        if current_page == 1:
            if edit_stage == 0:
                if edit_field in (0, 1):
                    if action == 'up':
                        if edit_field == 0: edit_hour = (edit_hour + 1) % 24
                        else: edit_minute = (edit_minute + 1) % 60
                    elif action == 'down':
                        if edit_field == 0: edit_hour = (edit_hour - 1) % 24
                        else: edit_minute = (edit_minute - 1) % 60
                if action == 'left':
                    edit_field = (edit_field - 1) % 4
                elif action == 'right':
                    edit_field = (edit_field + 1) % 4
                elif action == 'press':
                    if edit_field == 2:
                        edit_stage = 1
                        weekday_cursor = 0
                        beep(2500, 60)
                    elif edit_field == 3:
                        if alarm_selected < len(alarms):
                            alarms[alarm_selected]['hour'] = edit_hour
                            alarms[alarm_selected]['minute'] = edit_minute
                        else:
                            alarms.append({
                                'hour': edit_hour,
                                'minute': edit_minute,
                                'enabled': True,
                                'days': list(edit_days)
                            })
                        save_data()
                        edit_mode = False
                        beep(2500, 100)
                    else:
                        beep(2500, 60)
            else:
                # 星期选择
                if action == 'left':
                    weekday_cursor = (weekday_cursor - 1) % 10
                elif action == 'right':
                    weekday_cursor = (weekday_cursor + 1) % 10
                elif action == 'up':
                    if weekday_cursor >= 7:
                        weekday_cursor = 0
                elif action == 'down':
                    if weekday_cursor < 7:
                        weekday_cursor = 7
                elif action == 'press':
                    if weekday_cursor < 7:
                        edit_days[weekday_cursor] = 1 - edit_days[weekday_cursor]
                        beep(2500, 40)
                    elif weekday_cursor == 7:
                        # 工作日快捷
                        edit_days = [1,1,1,1,1,0,0]
                        beep(2500, 50)
                    elif weekday_cursor == 8:
                        # 周末快捷
                        edit_days = [0,0,0,0,0,1,1]
                        beep(2500, 50)
                    elif weekday_cursor == 9:
                        # 保存
                        if alarm_selected < len(alarms):
                            alarms[alarm_selected]['hour'] = edit_hour
                            alarms[alarm_selected]['minute'] = edit_minute
                            alarms[alarm_selected]['days'] = list(edit_days)
                        else:
                            alarms.append({
                                'hour': edit_hour,
                                'minute': edit_minute,
                                'enabled': True,
                                'days': list(edit_days)
                            })
                        save_data()
                        edit_mode = False
                        beep(2500, 100)
        elif current_page == 4:
            if action == 'press':
                dt = rtc.datetime()
                rtc.datetime((dt[0], dt[1], dt[2], 0, edit_hour, edit_minute, 0, 0))
                save_data()
                edit_mode = False
                beep(2500, 80)
            elif action == 'up':
                if edit_field == 0: edit_hour = (edit_hour + 1) % 24
                else: edit_minute = (edit_minute + 1) % 60
            elif action == 'down':
                if edit_field == 0: edit_hour = (edit_hour - 1) % 24
                else: edit_minute = (edit_minute - 1) % 60
            elif action == 'left':
                edit_field = (edit_field - 1) % 2
            elif action == 'right':
                edit_field = (edit_field + 1) % 2

    # ---------- 绘制当前页面 ----------
    if edit_mode:
        draw_edit_page()
    elif menu_mode:
        draw_alarm_menu()
    else:
        if current_page == 0:
            draw_time_page()
        elif current_page == 1:
            draw_alarm_page()
        elif current_page == 2:
            draw_countdown_page()
        elif current_page == 3:
            draw_calendar_page()
        elif current_page == 4:
            draw_settings_page()
        elif current_page == 5:
            draw_weather_page()

    time.sleep(0.05)
